package com.mb.project1.account.mapper;

import com.mb.project1.account.domain.AccountVO;
import com.mb.project1.account.domain.HistoryVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface AccountMapper {

    //tbl : account 계좌 정보 전체 조회
    public List<AccountVO> getAllAccountList();

    //잔액조회
    List<AccountVO> balanceCoin(@Param("userId") String userId, @Param("accountNumber") String accountNumber, @Param("password") String password);

    //송금 후 잔액조회 (필요없는 기능, 테스트)
    List<AccountVO> historyCoin(AccountVO accountVO);
//    List<AccountVO> historyCoin(AccountVO accountVO);

    //계좌 및 사용자 정보
    List<AccountVO> infoAccount(AccountVO accountVO);

    //tbl : account_history 계좌이력 전체 조회
    List<HistoryVO> accountAllHistory();

    // 계좌이력 사용자 조회
    List<HistoryVO> accountUserHistory(HistoryVO historyVO);

    //계좌 생성, 생성이력
    void createAccount(AccountVO accountVO);
    void createHistory(AccountVO accountVO);

    //계좌 삭제 (정말 db내부에 data 삭제가 아닌, 삭제여부 false -> true)
    void deleteAccount(AccountVO accountVO);

    //입금, 이력
    void insertCoin(AccountVO accountVO);
    void insertHistory(AccountVO accountVO);

    //출금, 이력
    void withdrawCoin(AccountVO accountVO);
    void withdrawHistory(AccountVO accountVO);

    //송금, OUT(출금 이력)
    void wireOutCoin(HistoryVO historyVO);
    void wireOutHistory(HistoryVO historyVO);

    // 송금, IN(입금 이력)
    void wireInCoin(HistoryVO historyVO);
    void wireInHistory(HistoryVO historyVO);

    //예외처리를 위한 매퍼

    //아이디와 계좌번호 확인
    public Integer checkId(@Param("userId") String userId, @Param("accountNumber") String accountNumber);

    //해당 게좌 비밀번호 확인
    public Integer checkIdPwAc(AccountVO accountVO);

    //계좌 1 (해당 계좌 거래가능 확인)
    public Integer checkExist(@Param("accountNumber") String accountNumber);

    //계좌 2 (송금받는 계좌 확인)
    public Integer checkInAc(@Param("accountNumber2") String accountNumber2);

    //계좌1,2 일치여부 (같다면 거래X)
    public Integer equalInOutAc(@Param("accountNumber") String accountNumber , @Param("accountNumber2") String accountNumber2);

    //잔액이 거래금액 양수확인
    public Integer checkBalance(@Param("balance") Double balance);

    // 거래금액 < 잔액
    public Integer checkMinus(@Param("balance") Double balance, @Param("accountNumber") String accountNumber);

    //계좌 삭제 시 잔액 0원 확인
    public Integer checkZero(@Param("accountNumber") String accountNumber);

    // 계좌 삭제 여부 (이용불가 계좌, 이미 제거된 계좌 확인)
    public Integer checkDeleted(@Param("accountNumber") String accountNumber);

}


//  public List<AccountVO> getIdPw
//         (@Param("accountNumber") String accountNumber,
//          @Param("userId") String userId,
//          @Param("password") String password);
//  List<AccountVO> createAccount(AccountVO accountVO);


