package com.mb.project1.account.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class HistoryDto {
    private String userId;            //사용자ID
    private String password;          //비밀번호

    private Double seq;
    private String accountNumber;     //계좌번호
    private String jobType;
    private Double transactionAmount;
    private Double balance;           //잔액
    private LocalDateTime transatedAt;  //생성일시
    private String remark;

    private String accountNumber2;     //계좌번호2
    private Double balance2;           //잔액

    private Boolean deleted;          //삭제여부
    private LocalDateTime createdAt;  //생성일시

    private String name;  //생성일시
    private String mobileNumber;  //생성일시
    private String emailAddress;
}
