package com.mb.project1.user.domain;

import lombok.Data;

@Data
public class UserVO {
  private String userId;        //사용자ID
  private String name;          //이름
  private String mobileNumber;  //전화번호
  private String emailAddress;  //이메일
}