package com.mb.project1.account.domain;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class AccountVO extends HistoryVO{
  private String userId;            //사용자ID
  private String accountNumber;     //계좌번호
  private String password;          //비밀번호
  private Double balance;           //잔액
  private String accountNumber2;     //계좌번호2
  private Double balance2;           //잔액

  private Boolean deleted;          //삭제여부= 거래불가능계좌 여부
  private LocalDateTime createdAt;  //생성일시

  private String name;  //생성일시
  private String mobileNumber;  //생성일시
  private String emailAddress;  //생성일시

//  private Double balance2;           //잔액2
}
