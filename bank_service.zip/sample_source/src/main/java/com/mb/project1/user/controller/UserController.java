package com.mb.project1.user.controller;

import com.mb.project1.user.domain.UserVO;
import com.mb.project1.user.dto.UserDto;
import com.mb.project1.user.service.UserService;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.annotation.*;

import java.util.List;

//user 테이블관리
@RestController
@RequestMapping("/user")
public class UserController {
    @Autowired
    private UserService userService;

    @ExceptionHandler(HttpMessageNotReadableException.class)
    public Object notReadableEx(@NotNull Exception e) {
        System.err.println(e.getClass());

        return "HttpMessageNotReadableException : 해당 형식을 읽을 수 없습니다.";
    }

    @ExceptionHandler(NullPointerException.class)
    public Object nullDataEx(@NotNull Exception e) {
        System.err.println(e.getClass());

        return "NullPointerException : 페이지가 존재하지않거나, 해당 값이 존재하지 않습니다.";
    }

    //@@@###값이 이미 존재할 경우에 예외처리
    @ExceptionHandler(DuplicateKeyException.class)
    public Object duplicateDataEx(@NotNull Exception e) {
        System.err.println(e.getClass());

        return "DuplicateKeyException : 해당 값이 이미 존재합니다.";
    }

    @ExceptionHandler(StringIndexOutOfBoundsException.class)
    public Object OutOfBoundsEx(@NotNull Exception e) {
        System.err.println(e.getClass());

        return "OutOfBoundsException : 잘못된 입력값입니다.";

    }

    /*-------------------------------USER----------------------하위 매핑--------------*/

    // user정보 전체 조회
    @GetMapping(value = "/all")
    public List<UserDto> selectAllUserList() {
//    public List<UserDto> selectAllUserList() {
        System.out.println("user정보 전체 조회 , Select All User List : GET");
        List<UserDto> userDtoList = userService.getAllUserList();

//        throw new RuntimeException();

        return userDtoList;
    }

    //가입하기 (이름, 번호, 이메일)
    @PostMapping(value = "/new")
    public List<UserDto> createUser(@RequestBody UserVO userVO) {
//    public List<UserDto> createUser(@PathVariable("name") String name, @PathVariable("mobile") String mobile, @PathVariable("email") String email) { //따로 분리해야하나..?

        //회원가입완료
        userService.createUser(userVO);
        System.out.println("회원가입 / 중복확인 , create User : POST");
        List<UserDto> userDtoList = userService.getUserByInfo(userVO);

        //@@@###아이디 생성 후 전체 내역 조회 (나중에 수정 후 해당 아이디 값만 조회 하며, Sign up/Sign in)
        return userDtoList;
    }

    //로그인(이름,번호 입력) 후 해당 정보 확인
    @PostMapping(value = "/signin")
//    public List<UserDto> signInUser(@RequestBody UserVO userVO) {
    public String signInUser(@RequestBody UserVO userVO) { //이름, 전화번호 로그인
        userService.checkUser(userVO.getUserId());
        userService.signInUser(userVO);
        System.out.println("로그인 , User Sign in : POST");

//        List<UserDto> userDtoList = userService.getUserByName();
        //@@@###아이디 생성 후 전체 내역 조회 (나중에 수정 후 해당 아이디 값만 조회 하며, Sign up/Sign in)
        //로그인 완료 후 서비스 이용(계좌 개설, 입출금 등)
//        List<UserDto> userDtoList = userService.getUserByNameAndMobile(name, mobile);

        System.out.println("return userService.getUserByNameAndMobile(userVO.getName(), userVO.getMobileNumber());" + userService.getUserByNameAndMobile(userVO.getName(), userVO.getMobileNumber()));
        return "http://localhost:3100/api/account/service"; //회원 확인 후 계좌개설 페이지 이동 CreateAccount
    }

    //id로 유저정보 확인
    @PostMapping("/id")
    public List<UserDto> selectUserId(@RequestBody UserVO userVO) {
        List<UserDto> userById = userService.getUserById(userVO);
        userService.checkUser(userVO.getUserId());

        System.out.println("userByIduserById"+userService.getUserById(userVO));

        return userById;
    }

    //유저정보로 id 확인
    @PostMapping("/info")
    public List<UserDto> selectUserInfo(@RequestBody UserVO userVO) {
        List<UserDto> userByInfo = userService.getUserByInfo(userVO);
        userService.checkName(userVO.getName());
        userService.checkMobile(userVO);
        userService.checkEmail(userVO);

        System.out.println("userService.checkUser(userVO.getName()); : " + userService.checkName(userVO.getName()));

        System.out.println("userByIduserById"+userService.getUserByInfo(userVO));

        return userByInfo;
    }


    // 해당 name user 조회 vo 와 dto 구분 못하고, vo만씀.. +name과 같은 중요한 db data를 url에 입력하지않는다. (노출X)
    @GetMapping("/{name}")
    public List<UserDto> selectUserName(@PathVariable("name") String name) {
        System.out.println("해당 name user 조회 , Select User : GET");

        List<UserDto> userName = userService.getUserByName(name);
        userService.checkName(name);

        System.out.println("userService.checkUser(name);"+userService.checkName(name));

//        throw new RuntimeException();

        return userName;
    }

    //이름 + 전화번호로 해당 정보조회
    @GetMapping("/search/{name}/{mobile}")
//  public List<UserVO> selectUserNameMobile(UserVO userVO) {
    public List<UserDto> selectUserNameMobile(@PathVariable String name, @PathVariable String mobile) {
        List<UserDto> userDto = userService.getUserByNameAndMobile(name, mobile);
        System.out.println("userDtoNameAndMobile" + userDto);

        return userDto;
    }

//    @GetMapping("/api/account/logging/")
//    public Object test() {
//        return "Hello World!";
//    }

    //전화번호로 해당 정보조회
    @GetMapping("/phone/{mobile}")
    public UserVO selectUserMobile(@PathVariable("mobile") String mobile) {
        UserVO userNumber = userService.getUserByMobile(mobile);
        List<UserDto> userDtoList = userService.getAllUserList();

        //table 배열해서 해당 값이 없다면.. 예외처리 값이 있으면 return, 없으면 exception


        return userNumber;

    }
}


//        System.out.println("userName : " + userName);
//        System.out.println("name=위치" + userName.toString().indexOf("name="));
//
//
//        //예외처리 : name= ~ mobileNumber= 사이의 값이 이름, 이름과 db에 존재하는지 여부 확인 , 1시간
//        String nameValue = userName.toString().
//                substring(userName.toString().indexOf("name=") + 5,
//                        userName.toString().indexOf("mobileNumber=") - 2);
//
//        System.out.println(nameValue + "nameValue");
//
//        if (!nameValue.equals((String) name)) {
//            System.out.println("name:" + name + "nameValue:" + nameValue + "해당 이름 정보가 없습니다.ㅜㅜ");
////            throw new NullPointerException();
//
//        } else {
//            System.out.println(name + "select success!!");
//        }


