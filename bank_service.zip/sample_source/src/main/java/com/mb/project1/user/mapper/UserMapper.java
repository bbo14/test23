package com.mb.project1.user.mapper;

import com.mb.project1.user.domain.UserVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface UserMapper {
    public List<UserVO> getAllUserList();

    public List<UserVO> getUserById(@Param("userId")String userId);
    public List<UserVO> getUserByInfo(UserVO userVO);
    public List<UserVO> getUserByName(@Param("name")String name);

    public List<UserVO> getUserByNameAndMobile(@Param("name") String name, @Param("mobile") String mobile);
//    public List<UserVO> getUserByNameAndMobile(@Param("name") String name, @Param("mobile") String mobile);

    //회원가입, 중복확인
    public void createUser(UserVO userVO);

//    public List<UserVO> checkName(@Param("name") String name);
    public Integer checkName(@Param("name") String name);
    public Integer checkUser(@Param("userId") String userId);
    public Integer checkMobile(UserVO userVO);
    public Integer checkEmail(UserVO userVO);
//    public Integer checkEmail(@Param("email") String email);

    UserVO getUserByMobile(String mobile);


//  public UserVO insertUser(@Param("name")String name, @Param("mobile")String mobile, @Param("email")String email);
//  public List<UserVO> getUserByNameAndMobile(String name, String mobile);
//  public List<UserVO> getUserByNameAndMobile(@Param("name") String name, @Param("mobile") String mobile); //param 어노테이션 : 다수의 변수를 입력할 때에 사용.
//  public List<UserVO> getUserByNameAndMobile(UserVO userVO);


//  public void signInUser(@Param("name") String name, @Param("mobile") String mobile);


//  public void insertUser(@Param("name")UserVO name , @Param("mobile")UserVO mobile, @Param("email")UserVO email);


//  public List<UserVO> insertUser(UserDto userDto);

//  void deleteUser(String name, String mobile, String email);
}
