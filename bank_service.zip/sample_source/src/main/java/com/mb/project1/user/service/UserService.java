package com.mb.project1.user.service;

import com.mb.project1.user.domain.UserVO;
import com.mb.project1.user.dto.UserDto;
import com.mb.project1.user.mapper.UserMapper;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.ExceptionHandler;

import java.util.ArrayList;
import java.util.List;

@Service
public class UserService {
    /*
     * 회원가입
     * 정보조회 (이름, 이름+번호, 이름+번호+이메일)
     * 정보수정 (update)
     * 회원탈퇴 (delete)
     */

    @Autowired
    private UserMapper userMapper;
    /*---------------------------------------------------*/


    @ExceptionHandler(HttpMessageNotReadableException.class)
    public Object NotReadableEx(@NotNull Exception e) {
        System.err.println(e.getClass());

        return "HttpMessageNotReadableException : ";
    }

    private List<UserDto> mapUserVOtoDto(List<UserVO> org) {
        List<UserDto> userDtoList = new ArrayList<UserDto>();

        org.forEach(v -> {                 //Value
            UserDto userDto = new UserDto();
            BeanUtils.copyProperties(v, userDto); //getter, setter VO-> DTO
            userDtoList.add(userDto);             //VO-> DTO배열에  .add(userDto)
        });
        return userDtoList;
        /*

        for(int i=0; i< userVOList.size(); i++){
            SearchUserRequest userDto = new SearchUserRequest();
            BeanUtils.copyProperties(userVOList.get(i), userDto);
            userDtoNameAndMobile.add(userDto);
        }

        */
//        lambda사용한 List foreach 문

//        userVOList.forEach(v -> {
//            UserDto userDto = new UserDto();
//            SearchUserRequest userDto = new SearchUserRequest();
//            BeanUtils.copyProperties(v, userDto);
//            userDtoName.add(userDto);
//        });

    }

    public boolean checkName(String name) {
        // DB에서 user 정보 존재하는지 체크
        Integer count = userMapper.checkName(name);

        // 있으면
        if (count > 0) {
            return true;
        }else{ //없으면
            throw new RuntimeException("checkName 해당 이름이 없거나 다릅니다.");
        }
    }

    public boolean checkUser(String userId) {
        // DB에서 user 정보 존재하는지 체크
        Integer count = userMapper.checkUser(userId);

        // 있으면

        //0 존재하지않음, 1존재
        if (count > 0) {
            return true;
        }else{ //없으면
            throw new RuntimeException("checkUser 해당 ID가 없거나 다릅니다.");
        }
    }

    public boolean checkMobile(UserVO userVO) {
        // DB에서 user 정보 존재하는지 체크
        Integer count = userMapper.checkMobile(userVO);

        // 있으면

        //0 존재하지않음, 1존재
        if (count > 0) {
            return true;
        }else{ //없으면
            throw new RuntimeException("checkMobile 해당 전화번호가 없거나 다릅니다.");
        }
    }

    public boolean checkEmail(UserVO userVO) {
        // DB에서 user 정보 존재하는지 체크
        Integer count = userMapper.checkEmail(userVO);

        // 있으면

        //0 존재하지않음, 1존재
        if (count > 0) {
            return true;
        }else{ //없으면
            throw new RuntimeException("checkEmail 이메일 주소가 없거나 다릅니다.");
        }
    }

    /*----------------------------상위 예외처리 USER 하위 Service--------------------------------*/

    //User 전체 조회
    public List<UserDto> getAllUserList() {
        List<UserVO> userVOList = userMapper.getAllUserList();
        List<UserDto> userDtoList = mapUserVOtoDto(userVOList);

        return userDtoList;
    }

    //회원가입, 중복확인
//  public void insertUser(String name , String mobile, String email) {
    public void createUser(UserVO userVO) {
        userMapper.createUser(userVO);
    }

    // 로그인
    public void signInUser(UserVO userVO) {
//        List<UserVO> userVOList = userMapper.getUserByNameAndMobile(userVO.getName(), userVO.getMobileNumber());
        List<UserVO> userVOList = userMapper.getUserById(userVO.getUserId());
        List<UserDto> userDtoList = mapUserVOtoDto(userVOList);

//        userMapper.signInUser(userVO);
//        System.out.println("userVO.setUserId(userVO.getUserIfd())"+userVO.setUserId(userVO.getUserId());
    }

    //회원정보(이름) 값 받기
    public List<UserDto> getUserByName(String name) {
        List<UserVO> userVOList = userMapper.getUserByName(name);
        List<UserDto> userDtoList = mapUserVOtoDto(userVOList);//new ArrayList<UserDto>();

        System.out.println("userMapper.getUserByName(name) : " + userMapper.getUserByName(name));

        return userDtoList;
    }

    public List<UserDto> getUserById(UserVO userVO){
        List<UserVO> userVOList = userMapper.getUserById(userVO.getUserId());
        List<UserDto> userDtoList = mapUserVOtoDto(userVOList);

        System.out.println("List<UserVO> userVOList = userMapper.getUserById(userVO.getUserId()" + userDtoList );

        return userDtoList;
    }

    public List<UserDto> getUserByInfo(UserVO userVO){
        List<UserVO> userVOList = userMapper.getUserByInfo(userVO);
        List<UserDto> userDtoList = mapUserVOtoDto(userVOList);

        System.out.println("List<UserVO> userVOList = userMapper.getUserById(userVO.getUserId()" + userDtoList );

        return userDtoList;
    }


    //회원정보(이름,전화번호) 값 받기
    public List<UserDto> getUserByNameAndMobile(String name, String mobile) {
        // 방법 1
        List<UserVO> userVOList = userMapper.getUserByNameAndMobile(name, mobile);
        List<UserDto> userDtoList = mapUserVOtoDto(userVOList);

        // 방법 2
//        UserVO userVO = new UserVO();
//        userVO.setName(name);
//        userVO.setMobileNumber(mobile);

//        List<UserVO> userDtoNameAndMobile = new ArrayList<UserVO>();
        System.out.println("userMapper.getUserByNameAndMobile(userVO)" + userMapper.getUserByNameAndMobile(name, mobile));

        return userDtoList;
    }


    public UserVO getUserByMobile(String mobile) {
        return userMapper.getUserByMobile(mobile);
    }

}








//
//    public boolean checkUser(String name) {
//        // DB에서 user 정보 존재하는지 체크
//        List<UserVO> userVOList = userMapper.checkUser(name);
//        List<UserDto> userDtoList = mapUserVOtoDto(userVOList);
//
//        System.out.println("userVOList : " + userVOList);
//        System.out.println("name=위치" + userVOList.toString().indexOf("name="));
////
////
//        //예외처리 : name= ~ mobileNumber= 사이의 값이 이름, 이름과 db에 존재하는지 여부 확인 , 1시간
//
//        String count = userVOList.toString().
//                substring(userVOList.toString().indexOf("count=") + 6,
//                        userVOList.toString().indexOf("count=") + 7);
//
//        System.out.println(count + "nameValue");
//
//        System.out.println("userVOList"+userVOList);
//        System.out.println("userDtoList"+userDtoList);
//        System.out.println("count.equals(1)"+count.equals(1));
//        System.out.println("count.equals(1)"+count.equals("1"));
//        System.out.println("count == \"1\""+count == "1");
//
//        // 있으면
//        if (count.equals("1")) {
//            return true;
//        }else{ //없으면
//            throw new RuntimeException("잘못된 정보입니다.");
//        }
//    }
//
//    public boolean checkUser(String name) {
//        // DB에서 user 정보 존재하는지 체크
//        List<UserVO> userVOList = userMapper.checkUser(name);
//        List<UserDto> userDtoList = mapUserVOtoDto(userVOList);
//
//        System.out.println("userVOList : " + userVOList);
//        System.out.println("name=위치" + userVOList.toString().indexOf("name="));
////
////
//        //예외처리 : name= ~ mobileNumber= 사이의 값이 이름, 이름과 db에 존재하는지 여부 확인 , 1시간
//
//        String count = userVOList.toString().
//                substring(userVOList.toString().indexOf("count=") + 6,
//                        userVOList.toString().indexOf("count=") + 7);
//
//        System.out.println(count + "nameValue");
//
//        System.out.println("userVOList"+userVOList);
//        System.out.println("userDtoList"+userDtoList);
//        System.out.println("count.equals(1)"+count.equals(1));
//        System.out.println("count.equals(1)"+count.equals("1"));
//        System.out.println("count == \"1\""+count == "1");
//
//        // 있으면
//        if (count.equals("1")) {
//            return true;
//        }else{ //없으면
//            throw new RuntimeException("잘못된 정보입니다.");
//        }
//    }