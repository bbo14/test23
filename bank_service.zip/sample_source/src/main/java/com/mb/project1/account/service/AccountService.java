package com.mb.project1.account.service;

import com.mb.project1.account.domain.AccountVO;
import com.mb.project1.account.domain.HistoryVO;
import com.mb.project1.account.dto.*;
import com.mb.project1.account.mapper.AccountMapper;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class AccountService {
    @Autowired
    private AccountMapper accountMapper;

    private List<AccountDto> mapAccountVOtoDto(List<AccountVO> org) {
        List<AccountDto> accountDtoList = new ArrayList<AccountDto>();

        org.forEach(v -> {                 //Value
            AccountDto accountDto = new AccountDto();
            BeanUtils.copyProperties(v, accountDto); //getter, setter VO-> DTO
            accountDtoList.add(accountDto);             //VO-> DTO배열에  .add(accountDto)
        });
        return accountDtoList;
    }

    // 잔액조회
    private List<BalanceDto> mapBalanceVOtoDto(List<AccountVO> org2) {
        List<BalanceDto> balanceDtoList = new ArrayList<BalanceDto>();

        org2.forEach(v -> {                 //Value
            BalanceDto balanceDto = new BalanceDto();
            BeanUtils.copyProperties(v, balanceDto); //getter, setter VO-> DTO
            balanceDtoList.add(balanceDto);             //VO-> DTO배열에  .add(accountDto)
        });
        return balanceDtoList;
    }

    private List<ServiceDto> mapServiceVOtoDto(List<AccountVO> org3) {
        List<ServiceDto> serviceDtoList = new ArrayList<ServiceDto>();

        org3.forEach(v -> {                 //Value
            ServiceDto serviceDto = new ServiceDto();
            BeanUtils.copyProperties(v, serviceDto); //getter, setter VO-> DTO
            serviceDtoList.add(serviceDto);             //VO-> DTO배열에  .add(accountDto)
        });
        return serviceDtoList;
    }

    private List<InfoDto> mapInfoVOtoDto(List<AccountVO> org4) {
        List<InfoDto> infoDtoList = new ArrayList<InfoDto>();

        org4.forEach(v -> {                 //Value
            InfoDto infoDto = new InfoDto();
            BeanUtils.copyProperties(v, infoDto); //getter, setter VO-> DTO
            infoDtoList.add(infoDto);             //VO-> DTO배열에  .add(accountDto)
        });
        return infoDtoList;
    }

    private List<HistoryDto> mapHistoryVOtoDto(List<HistoryVO> org5) {
        List<HistoryDto> historyDtoList = new ArrayList<HistoryDto>();

        org5.forEach(v -> {                 //Value
            HistoryDto historyDto = new HistoryDto();
            BeanUtils.copyProperties(v, historyDto); //getter, setter VO-> DTO
            historyDtoList.add(historyDto);             //VO-> DTO배열에  .add(accountDto)
        });
        return historyDtoList;
    }

    //계좌이력 전체 조회
    public List<HistoryDto> accountAllHistory() {
        List<HistoryVO> historyVOList = accountMapper.accountAllHistory();
        List<HistoryDto> historyDtoList = mapHistoryVOtoDto(historyVOList);

        return historyDtoList;
    }

    //계좌이력 개별
    public List<HistoryDto> accountUserHistory(HistoryVO historyVO) {
        List<HistoryVO> historyVOList = accountMapper.accountUserHistory(historyVO);
        List<HistoryDto> historyDtoList = mapHistoryVOtoDto(historyVOList);

        return historyDtoList;
    }

    //Account 전체 조회
    public List<AccountDto> getAllAccountList() {
        List<AccountVO> accountVOList = accountMapper.getAllAccountList();
        List<AccountDto> accountDtoList = mapAccountVOtoDto(accountVOList);

        return accountDtoList;
    }

    public boolean checkId(String userId, String accountNumber) {
        //해당 id가 보유한 ac인가
        Integer count = accountMapper.checkId(userId, accountNumber);
        System.out.println("checkId : count" + count);
        // 있으면
        if (count > 0) {
            return true;
        } else { //없으면
            throw new RuntimeException("IA check : Id, Ac ID 또는 계좌번호가 일치하지 않습니다.");
        }
    }

    public boolean checkMinus(Double balance, String accountNumber) {
        //거래금액 < 잔액
        Integer count = accountMapper.checkMinus(balance, accountNumber);
        System.out.println("checkMinus : count" + count);
        // 있으면
        if (count > 0) {
            return true;
        } else { //없으면
            throw new RuntimeException("잔액이 부족합니다. (거래금액 > 잔액)");
        }
    }

    public boolean equalInOutAc(String accountNumber, String accountNumber2) {
        //계좌1, 계좌2가 동일하지는 않는가
        Integer count = accountMapper.equalInOutAc(accountNumber, accountNumber2);
        System.out.println("equalInOutAc : count" + count);
        // 있으면
        if (count > 0) {
            throw new RuntimeException("equal account : 동일한 계좌번호로는 송금 할 수 없습니다.");
        } else { //없으면
            return true;
        }
    }

    public boolean checkIdPwAc(AccountVO accountVO) {
        //id ac 의 pw pw가 맞나
        Integer count = accountMapper.checkIdPwAc(accountVO);
        System.out.println("checkIdPwAc : count" + count);
        // 있으면
        if (count > 0) {
            return true;
        } else { //없으면
            throw new RuntimeException("IAP error : Id, Ac ID 또는 계좌번호 또는 비밀번호 가 일치하지 않습니다.");
        }
    }

    public boolean checkInAc(String accountNumber2) {
        //존재하는 계좌2인가 (송금받는계좌 존재여부)
        Integer count = accountMapper.checkInAc(accountNumber2);
        System.out.println("checkInAc : count" + count);
        // 있으면
        if (count > 0) {
            return true;
        } else { //없으면
            throw new RuntimeException("checkInAc error : 존재하지않거나 거래 불가능 계좌입니다.");
        }
    }

    public boolean checkBalance(Double balance) {
        //거래금액 : 양수를 입력했나
        Integer count = accountMapper.checkBalance(balance);
        System.out.println("balance : count" + count);

        // 있으면
        if (count > 0) {
            return true;
        } else { //없으면
            throw new RuntimeException("거래금액은 반드시 양수로 입력해야 합니다.");
        }
    }

    public boolean checkExist(String accountNumber) {
        //존재하며, 거래 가능한 계좌인가
        Integer count = accountMapper.checkExist(accountNumber);
        System.out.println("balance : count" + count);

        // 있으면
        if (count == 0) {
            return true;
        } else { //없으면
            throw new RuntimeException("거래가 불가능한 계좌입니다.(삭제,이용정지)");
        }
    }

    public boolean checkDeleted(String accountNumber) {
        //삭제가 이미 된 계정은 아닌가 ac1이든 2든 둘중에 거래불가능한 계좌가 있으면 노출되게 해야지..
        Integer count = accountMapper.checkDeleted(accountNumber);
        System.out.println("balance : count" + count);

        // 있으면
        if (count == 0) {
            return true;
        } else { //없으면
            throw new RuntimeException("이용불가 계좌 또는 이미 제거된 계좌 입니다.");
        }
    }

    public boolean checkZero(String accountNumber) {
        //계정 삭제 전에 잔금처리는 다했나
        Integer count = accountMapper.checkZero(accountNumber);
        System.out.println("balance : count" + count);

        // 있으면
        if (count == 1) {
            return true;
        } else { //없으면
            throw new RuntimeException("잔액이 0원이어야 계좌삭제가 가능합니다.");
        }
    }

    /*상단 예외처리-----------------------하단 서비스이용*/

    //계좌 생성
    public void createAccount(AccountVO accountVO) {
        accountMapper.createAccount(accountVO);
    }

    //계좌 이력 :계좌 생성
    public void createAccount2(AccountVO accountVO) {
        accountMapper.createHistory(accountVO);
    }



    //해당 계좌 정보 조회
    public List<InfoDto> infoAccount(AccountVO accountVO) {
        List<AccountVO> accountVOList = accountMapper.infoAccount(accountVO);
        List<InfoDto> infoDtoList = mapInfoVOtoDto(accountVOList);

        return infoDtoList;
    }

    //잔액 조회 (해당 user, Account..Balance )
    public List<BalanceDto> balanceCoin(AccountVO accountVO) {
        //입,출금
        List<AccountVO> accountVOList = accountMapper.balanceCoin(accountVO.getUserId(), accountVO.getAccountNumber(), accountVO.getPassword());
        List<BalanceDto> balanceDtoList = mapBalanceVOtoDto(accountVOList);

        return balanceDtoList;
    }

    //송금 후 잔액, 입금 조회 (해당 user, Account1,2 -Balance , +balance)
    public List<ServiceDto> historyCoin(AccountVO accountVO) {
        //입,출금
        List<AccountVO> accountVOList;
        accountVOList = accountMapper.historyCoin(accountVO);
        List<ServiceDto> serviceDtoList = mapServiceVOtoDto(accountVOList);

        return serviceDtoList;
    }

    //입금하기 ID, 계좌번호, balance += balacne
    public void insertCoin(AccountVO accountVO) {
        checkId(accountVO.getUserId(), accountVO.getAccountNumber());
        checkIdPwAc(accountVO);
        checkExist(accountVO.getAccountNumber());
        checkBalance(accountVO.getBalance()); //거래금액이 0원이상 여부
        accountMapper.insertCoin(accountVO);
    }

    //이력추가 : 입금하기 ID, 계좌번호, balance += balacne
    public void insertHistory(AccountVO accountVO) {
        accountMapper.insertHistory(accountVO);
    }

    //출금하기 ID, 계좌번호,비밀번호, balance -= balacne
    public void withdrawCoin(AccountVO accountVO) {
        checkId(accountVO.getUserId(), accountVO.getAccountNumber());
        checkIdPwAc(accountVO);
        checkExist(accountVO.getAccountNumber());
        checkBalance(accountVO.getBalance()); //거래금액이 0원이상 여부
        checkMinus(accountVO.getBalance(), accountVO.getAccountNumber()); // 잔액 > 거래 ?

        accountMapper.withdrawCoin(accountVO);
    }

    //이력추가 : 출금하기 ID, 계좌번호,비밀번호, balance -= balacne
    public void withdrawHistory(AccountVO accountVO) {
        accountMapper.withdrawHistory(accountVO);
    }

    //송금하기 ID, 계좌번호,비밀번호, balance -= balacne, 보낼 계좌번호 , balance += balance
    public void wireOutCoin(HistoryVO historyVO) {


        accountMapper.wireOutCoin(historyVO);
    }

    public void wireInCoin(HistoryVO historyVO) {


        accountMapper.wireInCoin(historyVO);
    }

    public void wireOutHistory(HistoryVO historyVO) {


        accountMapper.wireOutHistory(historyVO);
//
    }

    public void wireInHistory(HistoryVO historyVO) {

        accountMapper.wireInHistory(historyVO);
//        historyVO.setRemark("문자열");
//        String remark = "입금 금액은 " + 1000 + "원입니다.";
    }

    //계좌 삭제
    public void deleteAccount(AccountVO accountVO) {
        checkId(accountVO.getUserId(), accountVO.getAccountNumber());
        checkIdPwAc(accountVO);
        checkZero(accountVO.getAccountNumber());
        checkDeleted(accountVO.getAccountNumber());
//        deleteAccount(accountVO);
        accountMapper.deleteAccount(accountVO);
    }


}

//방법 2
// AccountVO.getName();
// AccountVO.getMobileNumber();

//        List<AccountVO> accountVOList = accountMapper.getAllAccountList();
//        List<AccountDto> accountDtoList = mapAccountVOtoDto(accountVOList);

//        AN,ID,PW
//        accountMapper.createAccount(accountVO);
//                accountMapper.getIdPw(accountVO.getAccountNumber(),
//                                            accountVO.getUserId(),
//                                            accountVO.getPassword());
//        List<AccountDto> AccountDtoList = mapAccountVOtoDto(accountVOList);

//    public boolean checkName(String name) {
//        // DB에서 user 정보 존재하는지 체크
//        Integer count = accountMapper.checkName(name);
//
//        // 있으면
//        if (count > 0) {
//            return true;
//        }else{ //없으면
//            throw new RuntimeException("checkName 해당 이름이 없거나 다릅니다.");
//        }
//    }
//
//    public boolean checkName(String name) {
//        // DB에서 user 정보 존재하는지 체크
//        Integer count = accountMapper.checkName(name);
//
//        // 있으면
//        if (count > 0) {
//            return true;
//        }else{ //없으면
//            throw new RuntimeException("checkName 해당 이름이 없거나 다릅니다.");
//        }
//    }
