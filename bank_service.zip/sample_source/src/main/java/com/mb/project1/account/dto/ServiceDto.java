package com.mb.project1.account.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ServiceDto {
    private String userId;            //사용자ID1
    private String accountNumber;     //계좌번호1
    private String password;          //비밀번호1
    private Double balance;           //잔액1
    private String accountNumber2;     //계좌번호2
    private Double balance2;           //잔액1
    private Boolean deleted;          //삭제여부
//    private Double balance2;           //잔액1
}

//1은 이미 유저id가지고 있음.
//송금할 본인 계좌 번호(1)와 비밀번호 입력

//2의 계좌번호와 보낼 금액 입력.
//1의 잔액 -coin //2의 잔액 +coin

