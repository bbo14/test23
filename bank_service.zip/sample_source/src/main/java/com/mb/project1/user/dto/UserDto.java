package com.mb.project1.user.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserDto {
  private String userId;        //사용자ID
  private String name;          //이름
  private String mobileNumber;  //전화번호
  private String emailAddress;  //이메일

//  private String count;

}

//  User user1 = new User(); // @NoArgsConstructor : 파라미터가 없는 기본 생성자 생성
//  User user2 = new User("user2", "1234"); // @RequiredArgsConstructor : final, @NonNull인 필드 값ㅅ만 파라미터로 받는 생성자 생성
//  User user3 = new User(1L, "user3", "1234", null); // @AllArgsConstructor : 모든 필드 값을 파라미터로 받는 생성자 생성