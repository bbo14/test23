package com.mb.project1.account.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class InfoDto {
    private String userId;            //사용자ID
    private String accountNumber;     //계좌번호
    private String password;          //비밀번호
    private Double balance;           //잔액
    private Boolean deleted;          //삭제여부
    private LocalDateTime createdAt;  //생성일시
    private String name;  //생성일시
    private String mobileNumber;  //생성일시
    private String emailAddress;  //생성일시
}