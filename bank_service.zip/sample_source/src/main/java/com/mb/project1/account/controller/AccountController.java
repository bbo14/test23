package com.mb.project1.account.controller;

import com.mb.project1.account.domain.AccountVO;
import com.mb.project1.account.domain.HistoryVO;
import com.mb.project1.account.dto.*;
import com.mb.project1.account.service.AccountService;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/account")
public class AccountController {
  @Autowired
  private AccountService accountService;
  //@@@###값이 존재하지 않을 때 예외처리
//    @RestControllerAdvice

  @ExceptionHandler(NullPointerException.class)
  public Object nullDataEx(@NotNull Exception e) {
    System.err.println(e.getClass());

    return "NullPointerException : 페이지가 존재하지않거나, 해당 값이 존재하지 않습니다.";
  }

  //@@@###값이 이미 존재할 경우에 예외처리
  @ExceptionHandler(DuplicateKeyException.class)
  public Object duplicateDataEx(@NotNull Exception e) {
    System.err.println(e.getClass());

    return "DuplicateKeyException : 해당 값이 이미 존재합니다.";
  }

  @ExceptionHandler(StringIndexOutOfBoundsException.class)
  public Object OutOfBoundsEx(@NotNull Exception e) {
    System.err.println(e.getClass());

    return "OutOfBoundsException : 잘못된 입력값입니다.";

  }

  @ExceptionHandler(HttpMessageNotReadableException.class)
  public Object NotReadableEx(@NotNull Exception e) {
    System.err.println(e.getClass());

    return "HttpMessageNotReadableException : ";
  }

//  @ExceptionHandler(SQLIntegrityConstraintViolationException.class)
//  public Object DulplicatePkEx(@NotNull Exception e) {
//    System.err.println(e.getClass());
//
//    return "SQLIntegrityConstraintViolationException : Duplicate entry, PK ";
//  }


  /*--------상위 예외 -----------------------ACCOUNT----------------------하위 매핑--------------*/
  @GetMapping(value="/all")
  public List<AccountDto> selectAllAcountList(){
    List<AccountDto> accountDtoList = accountService.getAllAccountList();

    return accountDtoList;
  }

  //@@@### 같은 경로로 get,post 쓸 수 있나
  @GetMapping("/new") //  @RequestMapping(value = "/", method = RequestMethod.GET)
  public Object test() {
    return "계좌 개설페이지 : POST~ ID, 희망 계좌번호,비밀번호 ";
  }

  @GetMapping("/service")
  public String serviceSystem(){
    return "계좌 개설 :http://localhost:3100/api/account/new\n" +
            "입금 :http://localhost:3100/api/account/insertCoin\n" +
            "출금 :http://localhost:3100/api/account/withdrawCoin\n" +
            "송금 개설 :http://localhost:3100/api/account/wireCoin\n"+
            "잔액조회 :http://localhost:3100/api/account/balanceCoin\n" +
            "계좌 이력 조회 :http://localhost:3100/api/account/history\n";

  }
  //계좌 정보 조회(id, ac, pw)
  @PostMapping("/info")
  public List<InfoDto> infoAccount(@RequestBody AccountVO accountVO) {
    List<InfoDto> infoDtoList = accountService.infoAccount(accountVO);

    return infoDtoList;
  }

  /* 서비스 사용*/

  //잔액조회하기
  @PostMapping("/balanceCoin")
  public List<BalanceDto> balanceCoin(@RequestBody AccountVO accountVO) {
    List<BalanceDto> balanceDtoList = accountService.balanceCoin(accountVO);

    return balanceDtoList;
  }

  //입금하기 ID, 계좌번호, balance += balacne
  @PutMapping("/insertCoin")
  public List<BalanceDto> insertCoin(@RequestBody AccountVO accountVO) {
//    List<BalanceDto> balanceDtoList = accountService.balanceCoin(accountVO);
//    accountService.checkId(accountVO.getUserId(), accountVO.getAccountNumber());
//    accountService.checkIdPwAc(accountVO);
//    accountService.checkBalance(accountVO.getBalance()); //거래금액이 0원이상 여부
//    accountService.checkDeleted(accountVO.getAccountNumber());

    accountService.insertCoin(accountVO);

    accountService.insertHistory(accountVO);


    ///@@@### 잔액조회를 시킬 것.
   return accountService.balanceCoin(accountVO);
  }

//출금하기
  @PutMapping("/withdrawCoin")
  public List<BalanceDto> withdrawCoin(@RequestBody AccountVO accountVO) {
//    accountService.checkId(accountVO.getUserId(), accountVO.getAccountNumber());
//    accountService.checkIdPwAc(accountVO);
//    accountService.checkBalance(accountVO.getBalance()); //거래금액이 0원이상 여부
//    accountService.checkMinus(accountVO.getBalance(), accountVO.getAccountNumber()); // 잔액 > 거래 ?
//    accountService.checkDeleted(accountVO.getAccountNumber());

    accountService.withdrawCoin(accountVO);
    accountService.withdrawHistory(accountVO);

    ///@@@### 잔액조회를 시킬 것.
    return accountService.balanceCoin(accountVO);
  }

// 송금하기
  @PutMapping("/wireCoin")
  public List<ServiceDto> wireCoin(@RequestBody AccountVO accountVO) {

    //AccountVO <-> HistoryVO
    accountService.checkExist(accountVO.getAccountNumber());  //존재하는 계좌1(서비스사용계좌)인가
    accountService.checkInAc(accountVO.getAccountNumber2());  //존재하는 계좌2인가
    accountService.equalInOutAc(accountVO.getAccountNumber(), accountVO.getAccountNumber2()); //계좌1, 계좌2가 동일하지는 않는가
    accountService.checkId(accountVO.getUserId(), accountVO.getAccountNumber()); //해당 id가 보유한 ac인가
    accountService.checkIdPwAc(accountVO); //id ac 의 pw pw가 맞나
    accountService.checkBalance(accountVO.getBalance()); //거래금액이 0원이상인가
    accountService.checkMinus(accountVO.getBalance(), accountVO.getAccountNumber()); //양수를 입력했나

    accountService.wireOutCoin(accountVO); //송금하는곳
    accountService.wireInCoin(accountVO);  //송금받는곳
    accountService.wireOutHistory(accountVO); //송금한 계좌이력
    accountService.wireInHistory(accountVO);  //송금받은 계좌이력

  ///@@@### 해당계좌와 받는 계좌 잔액조회를 시켜보자.
  return accountService.historyCoin(accountVO);
}
  //계좌 이력 조회
  @GetMapping("/history/all")
  public List<HistoryDto> accountHistory() {
    List<HistoryDto> historyDtoList = accountService.accountAllHistory();

    return historyDtoList;
  }
  //계좌 이력 조회
  @PostMapping("/history/user")
  public List<HistoryDto> accountHistory2(@RequestBody HistoryVO historyVO) {
    List<HistoryDto> historyDtoList2 = accountService.accountUserHistory(historyVO);

    return historyDtoList2;
  }



  //@@@###USER로그인 후 계좌개설, 서비스 사용 (계좌번호와 비밀번호), 인증완료 상태! , 계좌개설 and 비밀번호 설정
  @PostMapping("/new") //  @RequestMapping(value = "/", method = RequestMethod.POST)
  public List<BalanceDto> createAccount(@RequestBody AccountVO accountVO){

    accountService.createAccount(accountVO);
    accountService.createAccount2(accountVO);

    System.out.println("계좌 개설 / 중복확인, inser Account : POST");


//    계좌정보확인
    List<BalanceDto> accountDtoList = accountService.balanceCoin(accountVO);
//    System.out.println(accountService.createAccount(););

    return accountDtoList;
  }

  //계좌 삭제. deleted 값(0 -> 1)
  @PutMapping("/delete") //  @RequestMapping(value = "/", method = RequestMethod.POST)
  public String deleteAccount(@RequestBody AccountVO accountVO){

//    accountService.checkZero(accountVO.getAccountNumber());
    accountService.deleteAccount(accountVO);

    System.out.println("계좌 삭제 / deleted (false->true), inser Account : POST");


//    계좌정보확인
//    List<InfoDto> accountDtoList = accountService.infoAccount(accountVO);
//    System.out.println(accountService.createAccount(););

    return "해당 계좌 삭제가 되었습니다. 본 계좌는 거래 서비스 사용이 불가능 합니다.";
  }





  //로그인...

}
