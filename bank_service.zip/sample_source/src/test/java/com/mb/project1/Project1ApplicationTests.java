package com.mb.project1;

import org.testng.annotations.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Project1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
